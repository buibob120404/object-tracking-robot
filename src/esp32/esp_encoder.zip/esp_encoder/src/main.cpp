#include <Arduino.h>

#include "PinMap.h"
#include "WebServerManager.h"
#include "Config.h"
#include "IBUS.h"
#include "Motor.h"
#include "Manual.h"
#include "AutoMode.h"
#include "EncoderHW.h"

// ========================================================
// IBUS
// ========================================================

IBUS ibus(Serial2);
int ibusChannels[10];
// ========================================================
// MOTOR
// ========================================================

#define L_IN1 25
#define L_IN2 26
#define L_PWM 27

#define R_IN1 32
#define R_IN2 33
#define R_PWM 14

#define CH_L 0
#define CH_R 1

// ========================================================
// UART AUTO
// ========================================================

// #define AUTO_RX 18
// #define AUTO_TX 19

// ========================================================
// ENCODER
// ========================================================

#define ENC_L 34
#define ENC_R 35

// ========================================================
// MODE
// ========================================================

#define MODE_MANUAL_MAX 1500
#define MODE_AUTO_MAX   1800

#define IBUS_TIMEOUT 500

unsigned long lastIbusTime = 0;

enum RobotMode {

    MODE_MANUAL,
    MODE_AUTO,
    MODE_STOP
};

RobotMode currentMode = MODE_STOP;
RobotMode lastMode    = MODE_STOP;

// ========================================================
// MOTOR
// ========================================================

Motor motor(

    L_IN1,
    L_IN2,
    L_PWM,

    R_IN1,
    R_IN2,
    R_PWM,

    CH_L,
    CH_R
);

// ========================================================
// MANUAL
// ========================================================

Manual manual;

// ========================================================
// AUTO MODE
// ========================================================

// AutoMode autoMode(

//     Serial1,

//     AUTO_RX,
//     AUTO_TX
// );
AutoMode autoMode(

    Serial,

    0,
    0
);

// ========================================================
// ENCODER
// ========================================================

EncoderHW leftEncoder(

    PCNT_UNIT_0,
    ENC_L
);

EncoderHW rightEncoder(

    PCNT_UNIT_1,
    ENC_R
);

// ========================================================
// WEB SERVER
// ========================================================

WebServerManager web;

// ========================================================
// SETUP
// ========================================================

void setup() {

    // ===== DEBUG SERIAL =====
    Serial.begin(115200);

    Serial.println();
    Serial.println("BOOT");

    // ===== WEB SERVER =====
    web.begin();

    // ===== IBUS =====
    ibus.begin(

        115200,

        16,
        17
    );

    // ===== MOTOR =====
    motor.begin();

    // ===== ENCODER =====
    leftEncoder.begin();
    rightEncoder.begin();

    // ===== AUTO MODE =====
    autoMode.setEncoder(

        &leftEncoder,
        &rightEncoder
    );

    Serial.println("SYSTEM READY");
}

// ========================================================
// LOOP
// ========================================================

void loop() {

    // ====================================================
    // UPDATE ENCODER
    // ====================================================

    leftEncoder.update();

    rightEncoder.update();

    // ====================================================
    // UPDATE WEB SERVER
    // ====================================================

web.updateData(

    currentMode,

    leftEncoder.getCount(),
    rightEncoder.getCount(),

    ibusChannels
);

    // ====================================================
    // READ IBUS
    // ====================================================

    ibus.read();

    if (ibus.available()) {

        for(int i = 0; i < 10; i++)
{
    ibusChannels[i] =
        ibus.getChannel(i);
}
        lastIbusTime = millis();

        // =================================================
        // MODE CHANNEL
        // =================================================

        int ch8 = ibus.getChannel(

            config.modeChannel - 1
        );

        // =================================================
        // MODE SELECT
        // =================================================

        if (

            ch8 <
            config.manualMax
        ) {

            currentMode =
                MODE_MANUAL;
        }
        else if (

            ch8 <
            config.autoMax
        ) {

            currentMode =
                MODE_AUTO;
        }
        else {

            currentMode =
                MODE_STOP;
        }
    }

    // ====================================================
    // IBUS FAILSAFE
    // ====================================================

    if (

        millis() - lastIbusTime >
        config.ibusTimeout
    ) {

        currentMode =
            MODE_STOP;
    }

    // ====================================================
    // ENTER AUTO
    // ====================================================

    if (

        currentMode == MODE_AUTO &&
        lastMode    != MODE_AUTO
    ) {

        autoMode.begin();

        Serial.println(
            "ENTER AUTO MODE"
        );
    }

    // ====================================================
    // ENTER MANUAL
    // ====================================================

    if (

        currentMode == MODE_MANUAL &&
        lastMode    != MODE_MANUAL
    ) {

        Serial.println(
            "ENTER MANUAL MODE"
        );
    }

    // ====================================================
    // ENTER STOP
    // ====================================================

    if (

        currentMode == MODE_STOP &&
        lastMode    != MODE_STOP
    ) {

        Serial.println(
            "ENTER STOP MODE"
        );
    }

    // ====================================================
    // MOTOR COMMAND
    // ====================================================

    int leftCmd  = 0;
    int rightCmd = 0;

    // ====================================================
    // MANUAL MODE
    // ====================================================

    if (

        currentMode ==
        MODE_MANUAL
    ) {

        manual.run(

            ibus,

            leftCmd,
            rightCmd
            
        );
    }

    // ====================================================
    // AUTO MODE
    // ====================================================

    else if (

        currentMode ==
        MODE_AUTO
    ) {

        autoMode.run();

        leftCmd =
            autoMode.getLeftCmd();

        rightCmd =
            autoMode.getRightCmd();
        
    }

    // ====================================================
    // STOP MODE
    // ====================================================

    else {

        leftCmd  = 0;
        rightCmd = 0;
    }

    // ====================================================
    // OUTPUT MOTOR
    // ====================================================

    motor.set(

        leftCmd,
        rightCmd
    );

    // ====================================================
    // SAVE LAST MODE
    // ====================================================

    lastMode = currentMode;
}