#include "Config.h"

Config config = {

    8,
    1500,
    1800,
    500
};