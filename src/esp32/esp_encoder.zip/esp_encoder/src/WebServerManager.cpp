#include "WebServerManager.h"
#include "Config.h"

#include <WiFi.h>

String jsonData;

WebServerManager::WebServerManager()
    : server(80)
{
}

void WebServerManager::begin()
{
    WiFi.softAP(
        "ESP32_ROBOT",
        "12345678"
    );

    Serial.print("AP IP: ");
    Serial.println(
        WiFi.softAPIP()
    );

    prefs.begin(
        "robot",
        false
    );

    config.modeChannel =
        prefs.getInt(
            "modeCh",
            8
        );

    config.manualMax =
        prefs.getInt(
            "manualMax",
            1500
        );

    config.autoMax =
        prefs.getInt(
            "autoMax",
            1800
        );

    // ===== MAIN PAGE =====

    server.on(
        "/",
        HTTP_GET,
        [this](AsyncWebServerRequest *request)
        {

String html = R"rawliteral(

<!DOCTYPE html>

<html>

<head>

<meta name="viewport"
content="width=device-width, initial-scale=1">

<style>

body{
    font-family:Arial;
    margin:20px;
}

.bar{
    width:300px;
    height:20px;
    border:1px solid black;
    margin-bottom:10px;
}

.fill{
    height:100%;
    background:lime;
    width:0%;
}

</style>

</head>

<body>

<h2>ESP32 ROBOT</h2>

<div id="info"></div>

<div id="channels"></div>

<hr>

<h3>CONFIG</h3>

<form action="/save">

Mode Channel:<br>
<input name="modeCh"><br><br>

Manual Max:<br>
<input name="manualMax"><br><br>

Auto Max:<br>
<input name="autoMax"><br><br>

<input type="submit" value="SAVE">

</form>

<script>

function updateData()
{
    fetch('/data')
    .then(response => response.json())
    .then(data => {

        document.getElementById(
            "info"
        ).innerHTML =

            "MODE: " + data.mode +
            "<br>LEFT ENC: " + data.left +
            "<br>RIGHT ENC: " + data.right +
            "<hr>";

        let html = "";

        for(let i=0;i<10;i++)
        {
            let value = data.ch[i];

            let percent =
                ((value - 172) /
                (1811 - 172)) * 100;

            if(percent < 0)
                percent = 0;

            if(percent > 100)
                percent = 100;

            html +=
                "CH" + (i+1) +
                ": " + value +

                "<div class='bar'>" +

                "<div class='fill' style='width:" +
                percent +
                "%'></div></div>";
        }

        document.getElementById(
            "channels"
        ).innerHTML = html;
    });
}

setInterval(updateData,100);

updateData();

</script>

</body>
</html>

)rawliteral";

            request->send(
                200,
                "text/html",
                html
            );
        }
    );

    // ===== JSON DATA =====

    server.on(
        "/data",
        HTTP_GET,
        [this](AsyncWebServerRequest *request)
        {
            request->send(
                200,
                "application/json",
                jsonData
            );
        }
    );

    // ===== SAVE =====

    server.on(
        "/save",
        HTTP_GET,
        [this](AsyncWebServerRequest *request)
        {

            if(request->hasParam("modeCh"))
            {
                config.modeChannel =
                    request
                    ->getParam("modeCh")
                    ->value()
                    .toInt();

                prefs.putInt(
                    "modeCh",
                    config.modeChannel
                );
            }

            if(request->hasParam("manualMax"))
            {
                config.manualMax =
                    request
                    ->getParam("manualMax")
                    ->value()
                    .toInt();

                prefs.putInt(
                    "manualMax",
                    config.manualMax
                );
            }

            if(request->hasParam("autoMax"))
            {
                config.autoMax =
                    request
                    ->getParam("autoMax")
                    ->value()
                    .toInt();

                prefs.putInt(
                    "autoMax",
                    config.autoMax
                );
            }

            request->redirect("/");
        }
    );

    server.begin();
}

void WebServerManager::updateData(
    int mode,
    long leftEnc,
    long rightEnc,
    int *channels
)
{
    jsonData = "{";

    jsonData += "\"mode\":";
    jsonData += String(mode);

    jsonData += ",\"left\":";
    jsonData += String(leftEnc);

    jsonData += ",\"right\":";
    jsonData += String(rightEnc);

    jsonData += ",\"ch\":[";

    for(int i=0;i<10;i++)
    {
        jsonData +=
            String(channels[i]);

        if(i < 9)
            jsonData += ",";
    }

    jsonData += "]}";
}