#include "AutoMode.h"
#include "EncoderHW.h"

AutoMode::AutoMode(
    HardwareSerial &serialPort,
    int rxPin_,
    int txPin_
) {

    pcSerial = &serialPort;

    rxPin = rxPin_;
    txPin = txPin_;

    encoderLeft = nullptr;
    encoderRight = nullptr;

    motorLeftCmd = 0;
    motorRightCmd = 0;

    rxIndex = 0;

    lastSendTime = 0;
    lastCmdTime = 0;
}

// void AutoMode::begin() {
//     Serial.println("AUTO BEGIN");
//     pcSerial->begin(
//         115200,
//         SERIAL_8N1,
//         rxPin,
//         txPin
//     );

void AutoMode::begin() {
    pcSerial->println("RUN");

    lastCmdTime = millis();
}

void AutoMode::setEncoder(
    EncoderHW *left,
    EncoderHW *right
) {

    encoderLeft = left;
    encoderRight = right;
}

void AutoMode::sendEncoder() {

    if (millis() - lastSendTime >= 20) {

        lastSendTime = millis();

        pcSerial->print("ENC,");

        pcSerial->print(
    encoderLeft->getCount()
    );

        pcSerial->print(",");

        pcSerial->println(
    encoderRight->getCount()
    );
    }
}

void AutoMode::parseCommand(char *cmd) {

    if (strncmp(cmd, "CMD", 3) == 0) {

        int left;
        int right;

        int result = sscanf(
            cmd,
            "CMD,%d,%d",
            &left,
            &right
        );
            lastCmdTime = millis();
        if (result == 2) {

            motorLeftCmd =
                constrain(left, -255, 255);

            motorRightCmd =
                constrain(right, -255, 255);
        }
    }
    
}

void AutoMode::receiveCommand() {

    while (pcSerial->available()) {

        char c = pcSerial->read();

        if (c == '\n') {

            rxBuffer[rxIndex] = '\0';

            parseCommand(rxBuffer);

            rxIndex = 0;
        }
        else {

            if (
                rxIndex <
                sizeof(rxBuffer) - 1
            ) {

                rxBuffer[rxIndex++] = c;
            }
            else {

                rxIndex = 0;
            }
        }
    }
}

void AutoMode::run() {

    receiveCommand();

    sendEncoder();

    if (millis() - lastCmdTime > 300) {

        motorLeftCmd = 0;
        motorRightCmd = 0;
    }
}

int AutoMode::getLeftCmd() {
    return motorLeftCmd;

}

int AutoMode::getRightCmd() {
    return motorRightCmd;

}