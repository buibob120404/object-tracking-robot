#ifndef AUTOMODE_H
#define AUTOMODE_H

#include <Arduino.h>
#include "EncoderHW.h"

class AutoMode {
public:

    AutoMode(
        HardwareSerial &serialPort,
        int rxPin,
        int txPin
    );

    void begin();

    void run();

void setEncoder(
    EncoderHW *left,
    EncoderHW *right
);

    int getLeftCmd();

    int getRightCmd();

private:

    HardwareSerial *pcSerial;

    int rxPin;
    int txPin;

    EncoderHW *encoderLeft;
    EncoderHW *encoderRight;

    unsigned long lastSendTime;
    unsigned long lastCmdTime;

    int motorLeftCmd;
    int motorRightCmd;

    char rxBuffer[64];
    uint8_t rxIndex;

    void receiveCommand();

    void parseCommand(char *cmd);

    void sendEncoder();
};

#endif