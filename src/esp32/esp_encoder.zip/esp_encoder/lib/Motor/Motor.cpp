// 
#include "Motor.h"

#define PWM_FREQ 20000
#define PWM_RES 8

#define PWM_MIN 100
#define PWM_MAX 255
static int currentLeft = 0;
static int currentRight = 0;

#define DEAD_BAND 10
#define RAMP_STEP 8
Motor::Motor(
    int l_in1,
    int l_in2,
    int l_pwm,

    int r_in1,
    int r_in2,
    int r_pwm,

    int ch_l,
    int ch_r
) {

    L_IN1 = l_in1;
    L_IN2 = l_in2;
    L_PWM = l_pwm;

    R_IN1 = r_in1;
    R_IN2 = r_in2;
    R_PWM = r_pwm;

    CH_L = ch_l;
    CH_R = ch_r;
}

void Motor::begin() {

    pinMode(L_IN1, OUTPUT);
    pinMode(L_IN2, OUTPUT);

    pinMode(R_IN1, OUTPUT);
    pinMode(R_IN2, OUTPUT);

    ledcSetup(CH_L, PWM_FREQ, PWM_RES);
    ledcAttachPin(L_PWM, CH_L);

    ledcSetup(CH_R, PWM_FREQ, PWM_RES);
    ledcAttachPin(R_PWM, CH_R);

    stop();
}

void Motor::setMotor(
    int pwm,
    int in1,
    int in2,
    int ch
) {

    int outPwm = 0;

    if (pwm > 0) {
        digitalWrite(in1, HIGH);
        digitalWrite(in2, LOW);
        outPwm = map(
            constrain(pwm, 1, 255),
            1,
            255,
            PWM_MIN,
            PWM_MAX
        );
    }
    else if (pwm < 0) {
        digitalWrite(in1, LOW);
        digitalWrite(in2, HIGH);
        outPwm = map(
            constrain(-pwm, 1, 255),
            1,
            255,
            PWM_MIN,
            PWM_MAX
        );
    }
    else {

        digitalWrite(in1, LOW);
        digitalWrite(in2, LOW);

        outPwm = 0;
    }

    ledcWrite(ch, outPwm);
}
void Motor::set(
    int left,
    int right
) {
    Serial.print("INPUT  L=");
    Serial.print(left);

    Serial.print(" R=");
    Serial.println(right);
    left = constrain(left, -255, 255);
    right = constrain(right, -255, 255);

    if (abs(left) < DEAD_BAND)
        left = 0;

    if (abs(right) < DEAD_BAND)
        right = 0;

    if ((currentLeft > 0 && left < 0) ||
        (currentLeft < 0 && left > 0))
    {
        if (abs(currentLeft) > RAMP_STEP)
        {
            currentLeft += (currentLeft > 0)
                ? -RAMP_STEP
                : RAMP_STEP;
        }
        else
        {
            currentLeft = 0;
        }
    }
    else
    {
        if (currentLeft < left)
            currentLeft = min(currentLeft + RAMP_STEP, left);

        else if (currentLeft > left)
            currentLeft = max(currentLeft - RAMP_STEP, left);
    }

    if ((currentRight > 0 && right < 0) ||
        (currentRight < 0 && right > 0))
    {
        if (abs(currentRight) > RAMP_STEP)
        {
            currentRight += (currentRight > 0)
                ? -RAMP_STEP
                : RAMP_STEP;
        }
        else
        {
            currentRight = 0;
        }
    }
    else
    {
        if (currentRight < right)
            currentRight = min(currentRight + RAMP_STEP, right);

        else if (currentRight > right)
            currentRight = max(currentRight - RAMP_STEP, right);
    }
    Serial.print("OUTPUT L=");
    Serial.print(currentLeft);

    Serial.print(" R=");
    Serial.println(currentRight);
    setMotor(
        currentLeft,
        L_IN1,
        L_IN2,
        CH_L
    );

    setMotor(
        currentRight,
        R_IN1,
        R_IN2,
        CH_R
    );
}
void Motor::stop() {

    set(0, 0);
}