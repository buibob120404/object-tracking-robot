#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

class Motor {
public:

    Motor(
        int l_in1,
        int l_in2,
        int l_pwm,

        int r_in1,
        int r_in2,
        int r_pwm,

        int ch_l,
        int ch_r
    );

    void begin();

    void set(
        int left,
        int right
    );

    void stop();

private:

    int L_IN1;
    int L_IN2;
    int L_PWM;

    int R_IN1;
    int R_IN2;
    int R_PWM;

    int CH_L;
    int CH_R;

    void setMotor(
        int pwm,
        int in1,
        int in2,
        int ch
    );
};

#endif