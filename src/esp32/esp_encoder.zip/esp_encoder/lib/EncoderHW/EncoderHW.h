#ifndef ENCODER_HW_H
#define ENCODER_HW_H

#include <Arduino.h>
#include "driver/pcnt.h"

class EncoderHW {

private:

    pcnt_unit_t unit;

    int pin;

    volatile long count;

public:

    EncoderHW(
        pcnt_unit_t pcntUnit,
        int encoderPin
    );

    void begin();

    void update();

    long getCount();

    void reset();
};

#endif