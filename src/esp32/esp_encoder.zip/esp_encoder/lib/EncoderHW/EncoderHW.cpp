#include "EncoderHW.h"

EncoderHW::EncoderHW(
    pcnt_unit_t pcntUnit,
    int encoderPin
) {

    unit = pcntUnit;

    pin = encoderPin;

    count = 0;
}

void EncoderHW::begin() {

    pcnt_config_t config = {};

    config.pulse_gpio_num = pin;

    config.ctrl_gpio_num =
        PCNT_PIN_NOT_USED;

    config.unit = unit;

    config.channel =
        PCNT_CHANNEL_0;

    config.pos_mode =
        PCNT_COUNT_INC;

    config.neg_mode =
        PCNT_COUNT_DIS;

    config.lctrl_mode =
        PCNT_MODE_KEEP;

    config.hctrl_mode =
        PCNT_MODE_KEEP;

    config.counter_h_lim = 32767;

    config.counter_l_lim = -32768;

    pcnt_unit_config(&config);

    pcnt_counter_pause(unit);

    pcnt_counter_clear(unit);

    pcnt_counter_resume(unit);
}

void EncoderHW::update() {

    int16_t value;

    pcnt_get_counter_value(
        unit,
        &value
    );

    count = value;
}

long EncoderHW::getCount() {

    return count;
}

void EncoderHW::reset() {

    pcnt_counter_clear(unit);

    count = 0;
}