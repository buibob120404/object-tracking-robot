#ifndef IBUS_H
#define IBUS_H

#include <Arduino.h>

#define IBUS_BUFFSIZE 32
#define IBUS_MAXCHANNELS 14

class IBUS {
public:
    IBUS(HardwareSerial &serial);

    void begin(int baud, int rxPin, int txPin);
    void read();
    bool available();

    uint16_t getChannel(uint8_t ch);

private:
    HardwareSerial &_serial;

    uint8_t ibusIndex = 0;
    uint8_t ibus[IBUS_BUFFSIZE];
    uint16_t rcValue[IBUS_MAXCHANNELS];
    bool frameDone = false;
    unsigned long lastFrameTime = 0;
};

#endif