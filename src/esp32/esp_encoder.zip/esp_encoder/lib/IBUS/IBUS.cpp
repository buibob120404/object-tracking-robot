#include "IBUS.h"

IBUS::IBUS(HardwareSerial &serial)
    : _serial(serial)
{
}

void IBUS::begin(
    int baud,
    int rxPin,
    int txPin
) {

    _serial.begin(
        baud,
        SERIAL_8N1,
        rxPin,
        txPin
    );

    // ===== DEFAULT FAILSAFE =====

    for(int i = 0;
        i < IBUS_MAXCHANNELS;
        i++)
    {
        rcValue[i] = 1500;
    }

    lastFrameTime = millis();
}

void IBUS::read()
{
    while (_serial.available())
    {
        uint8_t val =
            _serial.read();

        if (
            ibusIndex == 0 &&
            val != 0x20
        ) {

            continue;
        }
        if (
            ibusIndex == 1 &&
            val != 0x40
        ) {

            ibusIndex = 0;

            continue;
        }
        ibus[ibusIndex++] = val;

        if (
            ibusIndex >=
            IBUS_BUFFSIZE
        ) {

            ibusIndex = 0;

            for (
                int i = 0;
                i < IBUS_MAXCHANNELS;
                i++
            ) {

                rcValue[i] =

                    (ibus[3 + i * 2] << 8)

                    |

                    ibus[2 + i * 2];
            }

            frameDone = true;

            lastFrameTime =
                millis();
        }
    }
}

bool IBUS::available()
{
    if(frameDone)
    {
        frameDone = false;

        return true;
    }

    return false;
}

uint16_t IBUS::getChannel(
    uint8_t ch
) {

    if(ch >= IBUS_MAXCHANNELS)
    {
        return 1500;
    }

    if(
        millis() - lastFrameTime
        > 500
    ) {
        return 1500;
    }
    return rcValue[ch];
}