#ifndef MANUAL_H
#define MANUAL_H

#include <Arduino.h>
#include "IBUS.h"

class Manual {
public:

    void run(
        IBUS &ibus,
        int &left,
        int &right
    );

private:

    int deadband(
        int val,
        int center = 1500,
        int range = 20
    );
};

#endif