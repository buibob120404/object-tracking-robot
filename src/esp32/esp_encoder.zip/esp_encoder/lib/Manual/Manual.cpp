#include "Manual.h"

// ==================== DEAD BAND ====================

int Manual::deadband(int val, int center, int range) {
    if (val > center - range && val < center + range) {
        return center;
    }
    return val;
}

// ==================== MAIN CONTROL ====================

void Manual::run(
    IBUS &ibus,
    int &left,
    int &right
) {

    static int leftOut = 0;
    static int rightOut = 0;

    int rawThrottle = deadband(
        ibus.getChannel(1),
        1500,
        60
    );

    int rawSteering = deadband(
        ibus.getChannel(0),
        1500,
        60
    );

    int maxSpeed = map(
        ibus.getChannel(8),
        1000,
        2000,
        80,
        255
    );

    int throttle = map(
        rawThrottle,
        1000,
        2000,
        -maxSpeed,
        maxSpeed
    );

    int steering = map(
        rawSteering,
        1000,
        2000,
        -255,
        255
    );
    steering =
        (long)steering *
        abs(steering) /
        255;

    int targetLeft;
    int targetRight;

    bool pivotMode =
        abs(rawThrottle - 1500) < 20;

    if (pivotMode) {

        // Đảo chiều pivot
        targetLeft  = -steering;
        targetRight = steering;
    }

    else {

        targetLeft  = throttle;
        targetRight = throttle;

        if (steering > 0) {

            targetRight =
                (long)throttle *
                (255 - steering) /
                255;
        }
        else {

            targetLeft =
                (long)throttle *
                (255 + steering) /
                255;
        }
    }
    const int rampStep = 5;

    if (leftOut < targetLeft) {
        leftOut += min(
            rampStep,
            targetLeft - leftOut
        );
    }
    else {
        leftOut -= min(
            rampStep,
            leftOut - targetLeft
        );
    }

    if (rightOut < targetRight) {
        rightOut += min(
            rampStep,
            targetRight - rightOut
        );
    }
    else {
        rightOut -= min(
            rampStep,
            rightOut - targetRight
        );
    }

    left = constrain(
        leftOut,
        -255,
        255
    );

    right = constrain(
        rightOut,
        -255,
        255
    );
}