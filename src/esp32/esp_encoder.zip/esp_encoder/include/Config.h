#ifndef CONFIG_H
#define CONFIG_H

struct Config {

    int modeChannel;

    int manualMax;

    int autoMax;

    int ibusTimeout;
};

extern Config config;

#endif