#pragma once

#include <ESPAsyncWebServer.h>
#include <Preferences.h>

class WebServerManager
{
public:

    WebServerManager();

    void begin();

    void updateData(
        int mode,
        long leftEnc,
        long rightEnc,
        int *channels
    );

private:

    AsyncWebServer server;

    Preferences prefs;
};